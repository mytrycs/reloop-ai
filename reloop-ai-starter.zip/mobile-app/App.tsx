// Entry point for React Native app
